package project1;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;



import java.awt.FlowLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import javax.swing.JProgressBar;

public class login extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
					login frame = new login();
					frame.setVisible(true);
				
	}

	/**
	 * Create the frame.
	 */
	public login() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setTitle("Login Page");
		setBounds(100, 100, 450, 381);
		setResizable(false);
		setLocationRelativeTo(this);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("PASSWORD");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_1.setBounds(31, 148, 94, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblUsername = new JLabel("USER ID");
		lblUsername.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblUsername.setBounds(31, 96, 94, 14);
		contentPane.add(lblUsername);
		
		JLabel lblUsertype = new JLabel("USERTYPE");
		lblUsertype.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblUsertype.setBounds(31, 196, 94, 14);
		contentPane.add(lblUsertype);
		
		textField = new JTextField();
		textField.setBounds(211, 95, 132, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		String arr[]={"Admin","Staff"};
		JComboBox comboBox = new JComboBox(arr);
		comboBox.setBounds(211, 195, 64, 20);
		contentPane.add(comboBox);
		comboBox.insertItemAt("Select", 0);
		comboBox.setSelectedIndex(0);
		
		
		
		
		JButton btnLogin = new JButton("LOGIN");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				
				
				
                String userid=textField.getText();
				
				char ch[]=passwordField.getPassword();//it returns char array
				String password=String.valueOf(ch);
				String type=(String)comboBox.getSelectedItem();
				System.out.println(userid+"::"+password+"::"+type);
				Connection con=DBInfo.getcon();
				int flag=0;
				if(type.equalsIgnoreCase("select"))
	    		  {
	    	  JOptionPane.showMessageDialog(login.this, "Please select a category", "Error", JOptionPane.ERROR_MESSAGE);
	    		  }
				
				if(type.equalsIgnoreCase("admin"))
				{
			      String query="select * from admin where username=? and password=?";
			      try
			      {
			    	  PreparedStatement ps=con.prepareStatement(query);
			    	  ps.setString(1, userid);
			    	  ps.setString(2, password);
			    	  ResultSet res=ps.executeQuery();
			    	  while(res.next())
			    	  {
			    		  flag=1;
			    		  break;
			    	  }
			      }
			      catch(Exception e)
			      {
			    	  e.printStackTrace();
			      }
			      if(flag==1)
			      {
			      Admin a=new Admin();
			      a.setVisible(true);dispose();
			      }
			      else
			      {
			    	  JOptionPane.showMessageDialog(login.this, "Wrong username or password", "Error", JOptionPane.ERROR_MESSAGE);
			      }
			      
				}
				if(type.equalsIgnoreCase("staff"))
				{
		String query="select * from employee_reg where Employee_id=? and password=?";
		try
	      {
	    	  PreparedStatement ps=con.prepareStatement(query);
	    	  ps.setString(1, userid);
	    	  ps.setString(2, password);
	    	  ResultSet res=ps.executeQuery();
	    	  while(res.next())
	    	  {
	    		  flag=1;
	    		  break;
	    	  }
	      }
	      catch(Exception e)
	      {
	    	  e.printStackTrace();
	      }
	      if(flag==1)
	      {
	     staff s=new staff();
	      s.setVisible(true);dispose();
	      }
	      else
	      {
	    	  JOptionPane.showMessageDialog(login.this, "Wrong username or password", "Error", JOptionPane.ERROR_MESSAGE);
	      }
	      
				}
				
			}
		});
		
		btnLogin.setBounds(31, 275, 89, 23);
		contentPane.add(btnLogin);
		
		JButton btnReset = new JButton("RESET");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
			
				textField.setText(null);
				comboBox.setSelectedIndex(0);
				passwordField.setText(null);
			}
		});
		btnReset.setBounds(143, 275, 89, 23);
		contentPane.add(btnReset);
		
		JButton btnRegistersignUp = new JButton("REGISTER");
		btnRegistersignUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				dispose();
				staff_reg obj=new staff_reg();
				obj.setVisible(true);
				
				
			}
		});
		btnRegistersignUp.setBounds(254, 275, 101, 23);
		contentPane.add(btnRegistersignUp);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(211, 147, 132, 20);
		contentPane.add(passwordField);
		
		JButton btnHome = new JButton("HOME");
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				homepage obj=new homepage();
				obj.setVisible(true);
				dispose();
				
			}
		});
		btnHome.setBounds(143, 309, 89, 23);
		contentPane.add(btnHome);
		
		
	}
}

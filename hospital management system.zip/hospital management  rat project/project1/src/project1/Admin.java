package project1;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JToolBar;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import java.awt.CardLayout;
import java.awt.Canvas;
import java.awt.Button;
import javax.swing.JLabel;
import javax.swing.ImageIcon;

public class Admin extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Admin frame = new Admin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Admin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 644, 633);
		setTitle("Admin Page");

		setResizable(false);
		setLocationRelativeTo(this);
		contentPane = new JPanel();
		
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(1, 0, 0, 0));
		
		JSplitPane splitPane = new JSplitPane();
		splitPane.setOrientation(JSplitPane.VERTICAL_SPLIT);
		contentPane.add(splitPane);
		
		JToolBar toolBar = new JToolBar();
		splitPane.setLeftComponent(toolBar);
		
		Button button_3 = new Button("Update/View  employees' record");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				view_employee obj=new view_employee();
				obj.setVisible(true);
			}
		});
		toolBar.add(button_3);
		
		Button button_2 = new Button("Update/View  doctors' records");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				view_doctor obj=new view_doctor();
				obj.setVisible(true);
			}
		});
		toolBar.add(button_2);
		
		Button button_1 = new Button("Update/View Patients' records");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				view_patient obj=new view_patient();
				obj.setVisible(true);
			}
		});
		toolBar.add(button_1);
		
		JSplitPane splitPane_1 = new JSplitPane();
		splitPane.setRightComponent(splitPane_1);
		
		JToolBar toolBar_1 = new JToolBar();
		toolBar_1.setOrientation(SwingConstants.VERTICAL);
		splitPane_1.setLeftComponent(toolBar_1);
		
		Button button_4 = new Button("Register an employee");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		toolBar_1.add(button_4);
		
		Button button_5 = new Button("Register a doctor");
		toolBar_1.add(button_5);
		
		Button button = new Button("Register a patient");
		button.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				patient_reg obj=new patient_reg();
				obj.setVisible(true);
				
			}
		});
		button_5.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				doctor_reg obj=new doctor_reg();
				obj.setVisible(true);
				
			}
		});
		toolBar_1.add(button);
		
		Button button_6 = new Button("LOGOUT");
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				homepage obj=new homepage();
				obj.setVisible(true);
			}
		});
		toolBar_1.add(button_6);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("D:\\RAT\\project1\\src\\20160909123538.png"));
		splitPane_1.setRightComponent(lblNewLabel);
		 button_4.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				staff_reg obj=new staff_reg();
				obj.setVisible(true);
				// TODO Auto-generated method stub
				
			}
		});
	}
}

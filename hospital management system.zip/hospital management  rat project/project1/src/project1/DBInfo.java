package project1;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBInfo 
{

	private static final String Connection = null;

	static
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver loaded");
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
	}
        
		static Connection getcon()
		{
			Connection con=null;
			try
			{
			  con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management","root","transformers");
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			return con;
		}
	}
	

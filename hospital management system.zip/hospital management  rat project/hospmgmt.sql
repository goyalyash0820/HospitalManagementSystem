/*
SQLyog Enterprise - MySQL GUI v7.02 
MySQL - 5.0.67-community-nt : Database - hospital_management
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`hospital_management` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `hospital_management`;

/*Table structure for table `admin` */

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `username` varchar(20) NOT NULL,
  `password` varchar(30) default NULL,
  PRIMARY KEY  (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `admin` */

insert  into `admin`(`username`,`password`) values ('admin','admin');

/*Table structure for table `bill` */

DROP TABLE IF EXISTS `bill`;

CREATE TABLE `bill` (
  `Patient_ID` varchar(20) NOT NULL,
  `Billing_Date` varchar(20) default NULL,
  `No_Of_Days` varchar(10) default NULL,
  `Room_Charges` varchar(20) default NULL,
  `Service_Charges` varchar(20) default NULL,
  `Total_Charges` varchar(20) default NULL,
  PRIMARY KEY  (`Patient_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `bill` */

insert  into `bill`(`Patient_ID`,`Billing_Date`,`No_Of_Days`,`Room_Charges`,`Service_Charges`,`Total_Charges`) values ('01','1/1/2010','2','2000','200','2200');

/*Table structure for table `discharge` */

DROP TABLE IF EXISTS `discharge`;

CREATE TABLE `discharge` (
  `Patient_ID` varchar(40) NOT NULL,
  `Patient_Name` varchar(30) default NULL,
  `Discharge_Date` varchar(20) default NULL,
  `Remarks` varchar(60) default NULL,
  PRIMARY KEY  (`Patient_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `discharge` */

insert  into `discharge`(`Patient_ID`,`Patient_Name`,`Discharge_Date`,`Remarks`) values ('01','akash singh','1/1/2010','recovering');

/*Table structure for table `doctor_reg` */

DROP TABLE IF EXISTS `doctor_reg`;

CREATE TABLE `doctor_reg` (
  `Doctor_ID` varchar(20) NOT NULL,
  `Doctor_Name` varchar(30) default NULL,
  `DOB` varchar(40) default NULL,
  `Gender` varchar(15) default NULL,
  `Email` varchar(40) default NULL,
  `Mobile_No` varchar(20) default NULL,
  `Qualifications` varchar(30) default NULL,
  `Specialization` varchar(40) default NULL,
  `Date_Of_Joining` varchar(20) default NULL,
  `Address` varchar(60) default NULL,
  PRIMARY KEY  (`Doctor_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `doctor_reg` */

insert  into `doctor_reg`(`Doctor_ID`,`Doctor_Name`,`DOB`,`Gender`,`Email`,`Mobile_No`,`Qualifications`,`Specialization`,`Date_Of_Joining`,`Address`) values ('','','1/1/2010','Select','','','','','1/1/2010',''),('01','aditya johari','1/1/1996','MALE','aditya johari','01','radiology dd','mbbs','1/1/2010','sns');

/*Table structure for table `employee_reg` */

DROP TABLE IF EXISTS `employee_reg`;

CREATE TABLE `employee_reg` (
  `Employee_ID` varchar(20) NOT NULL,
  `Employee_Name` varchar(30) default NULL,
  `DOB` varchar(40) default NULL,
  `Gender` varchar(15) default NULL,
  `Email` varchar(40) default NULL,
  `Mobile_No` varchar(20) default NULL,
  `Qualifications` varchar(30) default NULL,
  `Specialization` varchar(40) default NULL,
  `Date_Of_Joining` varchar(20) default NULL,
  `Address` varchar(60) default NULL,
  `Password` varchar(30) default NULL,
  PRIMARY KEY  (`Employee_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `employee_reg` */

insert  into `employee_reg`(`Employee_ID`,`Employee_Name`,`DOB`,`Gender`,`Email`,`Mobile_No`,`Qualifications`,`Specialization`,`Date_Of_Joining`,`Address`,`Password`) values ('','','1/1/2010','SELECT','','','','','1/1/2010','',''),('00','','1/1/2010','SELECT','','','','','1/1/2010',NULL,'11'),('002','anisha goyal','1/1/2010','MALE','anishagoyal','9988776655','btech','cse','1/1/2012','imli phatak	','anishagoyal'),('007','ad','1/1/2010','SELECT','','','','','1/1/2010',NULL,''),('01','aditya johari shankar','computer science ','1/1/2010','2/2/2010','MALE','johariaditya96@gmail.com','9602636770','btech','','aditya'),('123','adiaaaya','q','q','1/1/2010','1/1/2010','MALE','aa','000','ddd','hello'),('1234','aditya','2/1/2010','MALE',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('14ejccs046','Chinmay Bisen','21/3/2010','MALE','chinmaybisen@gmail.com','8854923721','btech','cs','1/1/2010',NULL,'Qwerty123*');

/*Table structure for table `patient_reg` */

DROP TABLE IF EXISTS `patient_reg`;

CREATE TABLE `patient_reg` (
  `Patient_ID` varchar(20) NOT NULL,
  `Patient_Name` varchar(40) default NULL,
  `Disease` varchar(50) default NULL,
  `Gender` varchar(30) default NULL,
  `Room_No` varchar(10) default NULL,
  `Admit_Date` varchar(40) default NULL,
  `Status` varchar(20) default NULL,
  `Doctor_ID` varchar(40) default NULL,
  `Mobile_No` varchar(20) default NULL,
  `Remarks` varchar(100) default NULL,
  PRIMARY KEY  (`Patient_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `patient_reg` */

insert  into `patient_reg`(`Patient_ID`,`Patient_Name`,`Disease`,`Gender`,`Room_No`,`Admit_Date`,`Status`,`Doctor_ID`,`Mobile_No`,`Remarks`) values ('','','','Select','','1/1/2010','','','',''),('01','akash singh','catarcat','MALE','21','1/1/2010','admitted','01','9999999999','recovering');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
